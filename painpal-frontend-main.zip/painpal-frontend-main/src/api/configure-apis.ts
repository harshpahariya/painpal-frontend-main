export const FETCH_PAIN_QUESTIONS = `${(import.meta as any).env.VITE_BASE_URL || 'http://localhost:8080'}/fetch`;
export const FETCH_PAIN_RESULT = `${(import.meta as any).env.VITE_BASE_URL || 'http://localhost:8080'}/insert`;



